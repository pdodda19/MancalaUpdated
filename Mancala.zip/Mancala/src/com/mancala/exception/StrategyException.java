package com.mancala.exception;

public class StrategyException extends MancalaException {

	private static final long serialVersionUID = 1L;

	public StrategyException(String message) {
		super(message);
	}

	public StrategyException() {
	}

	public StrategyException(String message, Throwable cause) {
		super(message, cause);
	}

	public StrategyException(Throwable cause) {
		super(cause);
	}

}
