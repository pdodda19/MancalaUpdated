package com.mancala.exception;

public class MancalaException extends Exception{
  
	private static final long serialVersionUID = 1L;

	public MancalaException(String message) {
        super(message);
    }

    public MancalaException() {
    }

    public MancalaException(String message, Throwable cause) {
        super(message, cause);
    }

    public MancalaException(Throwable cause) {
        super(cause);
    }


}
