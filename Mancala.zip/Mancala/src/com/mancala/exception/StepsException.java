package com.mancala.exception;

public class StepsException extends MancalaException {

	private static final long serialVersionUID = 1L;

	public StepsException(String message) {
		super(message);
	}

	public StepsException() {
	}

	public StepsException(String message, Throwable cause) {
		super(message, cause);
	}

	public StepsException(Throwable cause) {
		super(cause);
	}

}
