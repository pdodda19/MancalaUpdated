package com.mancala.service;

import java.io.IOException;

import com.mancala.exception.StepsException;
import com.mancala.exception.StrategyException;
import com.mancala.model.Game;

public class Strategy {
	Steps util = new Steps();

	/* Getting the best possible move */
	public void getGamePlay(Game game) throws StrategyException {
		Game move = getAllMoves(game);
		try {
			util.writeNextState(move);
		} catch (StepsException | IOException ex) {
			throw new StrategyException(ex.getMessage());
		}
	}

	/* Getting all possible valid moves and selecting the best one */
	public Game getAllMoves(Game game) {
		double maxEval = Double.NEGATIVE_INFINITY;
		Game move = new Game(game);

		for (int i = 0; i < game.getBoardSize(); i++) {
			Game temp = new Game(game);
			if (!util.gameOver(temp)) {
				if (temp.getPlayer() == 1) {
					int[] localBoardOne = new int[temp.getBoardSize()];
					System.arraycopy(temp.getBoardPlayerOne(), 0, localBoardOne, 0, temp.getBoardSize());
					if (localBoardOne[i] > 0) {
						temp = new Game(util.moveStones(temp, temp.getPlayer(), i));
						if (temp.getAnotherTurn()) {
							temp = new Game(getAllMoves(temp));
						}
						if (maxEval < util.eval(temp.getPlayer(), temp.getMancalaPlayerOne(),
								temp.getMancalaPlayerTwo())) {
							maxEval = util.eval(temp.getPlayer(), temp.getMancalaPlayerOne(),
									temp.getMancalaPlayerTwo());
							move = new Game(temp);
							if (util.gameOver(move))
								break;
						}
					}
				} else {
					int[] localBoardTwo = new int[temp.getBoardSize()];
					System.arraycopy(temp.getBoardPlayerTwo(), 0, localBoardTwo, 0, temp.getBoardSize());
					if (localBoardTwo[i] > 0) {
						temp = new Game(util.moveStones(temp, temp.getPlayer(), i));
						if (temp.getAnotherTurn()) {
							temp = new Game(getAllMoves(temp));
						}
						if (maxEval < util.eval(temp.getPlayer(), temp.getMancalaPlayerOne(),
								temp.getMancalaPlayerTwo())) {
							maxEval = util.eval(temp.getPlayer(), temp.getMancalaPlayerOne(),
									temp.getMancalaPlayerTwo());
							move = new Game(temp);
							if (util.gameOver(move))
								break;
						}
					}
				}

			}
		}
		return move;
	}
}
