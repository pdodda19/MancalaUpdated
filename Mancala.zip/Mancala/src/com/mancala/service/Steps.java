package com.mancala.service;

import com.mancala.exception.StepsException;
import com.mancala.model.Game;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Logger;

public class Steps {

	private int[] boardOne;
	private int[] localBoardTwo;
	private int localMancalaOne;
	private int localMancalaTwo;
	private static final Logger log = Logger.getLogger(Steps.class.getName());

	/* Intialize the values to the variables */
	public void setLocals(Game game) {
		this.localMancalaOne = game.getMancalaPlayerOne();
		this.localMancalaTwo = game.getMancalaPlayerTwo();
		boardOne = new int[game.getBoardSize()];
		localBoardTwo = new int[game.getBoardSize()];
		System.arraycopy(game.getBoardPlayerOne(), 0, boardOne, 0, game.getBoardSize());
		System.arraycopy(game.getBoardPlayerTwo(), 0, localBoardTwo, 0, game.getBoardSize());
	}

	/* Processing the movement of stones */
	public Game moveStones(Game game, int player, int index) {
		Game state = new Game(game);
		state.setAnotherTurn(false);
		setLocals(state);
		if (player == 1) {
			playerOneChance(index, state);
		} else {
			playerTwoChance(index, state);
		}
		if (starvationPlayerOne(boardOne)) {
			for (int i = 0; i < localBoardTwo.length; i++) {
				localMancalaTwo += localBoardTwo[i];
				localBoardTwo[i] = 0;
			}
			state.setAnotherTurn(false);
		}
		if (starvationPlayerTwo(localBoardTwo)) {
			for (int i = 0; i < boardOne.length; i++) {
				localMancalaOne += boardOne[i];
				boardOne[i] = 0;
			}
			state.setAnotherTurn(false);
		}

		state.setBoardPlayerOne(boardOne);
		state.setBoardPlayerTwo(localBoardTwo);
		state.setMancalaPlayerOne(localMancalaOne);
		state.setMancalaPlayerTwo(localMancalaTwo);
		return state;
	}

	private void playerOneChance(int index, Game state) {
		if (boardOne[index] > 0) {
			int stones = boardOne[index];
			log.info("Index value:" + stones);
			boardOne[index] = 0;
			int j = index + 1;
			boolean reverse = false;
			while (stones > 0) {
				if (j == state.getBoardSize()) {
					if (stones == 1)
						state.setAnotherTurn(true);
					localMancalaOne++;
					stones--;
					reverse = true;
					j = state.getBoardSize() - 1;
				} else if (j < 0) {
					j = 0;
					reverse = false;
				} else if (reverse) {
					localBoardTwo[j]++;
					stones--;
					j--;
				} else {
					if (stones == 1 && boardOne[j] == 0) {
						localMancalaOne += localBoardTwo[j] + 1;
						localBoardTwo[j] = 0;
						stones--;
					} else {
						boardOne[j]++;
						stones--;
						j++;
					}
				}
			}
		}
	}

	private void playerTwoChance(int index, Game state) {
		if (localBoardTwo[index] > 0) {
			int stones = localBoardTwo[index];
			localBoardTwo[index] = 0;
			int j = index - 1;
			boolean reverse = true;
			while (stones > 0) {
				if (j < 0) {
					if (stones == 1)
						state.setAnotherTurn(true);
					localMancalaTwo++;
					stones--;
					reverse = false;
					j = 0;
				} else if (j == state.getBoardSize()) {
					j = state.getBoardSize() - 1;
					reverse = true;
				} else if (!reverse) {
					boardOne[j]++;
					stones--;
					j++;
				} else {
					if (stones == 1 && localBoardTwo[j] == 0) {
						localMancalaTwo += boardOne[j] + 1;
						boardOne[j] = 0;
						stones--;
					} else {
						localBoardTwo[j]++;
						stones--;
						j--;
					}
				}
			}
		}
	}

	/* This method will give the status of the game */
	public boolean gameOver(Game game) {
		int[] tempOne = new int[game.getBoardSize()];
		int[] tempTwo = new int[game.getBoardSize()];
		System.arraycopy(game.getBoardPlayerOne(), 0, tempOne, 0, game.getBoardSize());
		System.arraycopy(game.getBoardPlayerTwo(), 0, tempTwo, 0, game.getBoardSize());
		boolean sideOneEmpty = true;
		boolean sideTwoEmpty = true;
		for (int i = 0; i < game.getBoardSize(); i++) {
			if (tempOne[i] > 0) {
				sideOneEmpty = false;
				break;
			}
		}
		for (int i = 0; i < game.getBoardSize(); i++) {
			if (tempTwo[i] > 0) {
				sideTwoEmpty = false;
				break;
			}
		}
		return (sideOneEmpty || sideTwoEmpty);
	}

	public int eval(int player, int mancalaOne, int mancalaTwo) {
		return (player == 1) ? (mancalaOne - mancalaTwo) : (mancalaTwo - mancalaOne);
	}

	/* Game move will be logged in the state_of_game.txt file */
	public void writeNextState(Game move) throws StepsException, IOException {
		FileOutputStream fileOutputStreamNextState = new FileOutputStream("state_of_game.txt");
		OutputStreamWriter outputStreamWriterNextState = new OutputStreamWriter(fileOutputStreamNextState);
		BufferedWriter bufferedWriterNextState = new BufferedWriter(outputStreamWriterNextState);

		int[] tempOne = new int[move.getBoardSize()];
		int[] tempTwo = new int[move.getBoardSize()];
		System.arraycopy(move.getBoardPlayerOne(), 0, tempOne, 0, move.getBoardSize());
		System.arraycopy(move.getBoardPlayerTwo(), 0, tempTwo, 0, move.getBoardSize());
		StringBuilder boardSizeOne = new StringBuilder();
		StringBuilder boardSizeTwo = new StringBuilder();
		for (int i = 0; i < move.getBoardSize(); i++) {
			boardSizeOne = boardSizeOne.append(tempOne[i]).append(" ");
			boardSizeTwo = boardSizeTwo.append(tempTwo[i]).append(" ");
		}
		try {
			bufferedWriterNextState.write(boardSizeTwo.toString().trim());
			bufferedWriterNextState.newLine();
			bufferedWriterNextState.write(boardSizeOne.toString().trim());
			bufferedWriterNextState.newLine();
			bufferedWriterNextState.write(Integer.toString(move.getMancalaPlayerTwo()).trim());
			bufferedWriterNextState.newLine();
			bufferedWriterNextState.write(Integer.toString(move.getMancalaPlayerOne()).trim());
		} catch (FileNotFoundException ex) {
			throw new StepsException(ex.getMessage());
		} catch (IOException ex) {
			throw new StepsException(ex.getMessage());
		} finally {
			bufferedWriterNextState.close();
			outputStreamWriterNextState.close();
			fileOutputStreamNextState.close();
		}

	}

	public boolean starvationPlayerOne(int[] boardPlayerOne) {

		return Arrays.stream(boardPlayerOne).allMatch(val -> val < 0);
	}

	public boolean starvationPlayerTwo(int[] boardPlayer2) {

		return Arrays.stream(boardPlayer2).allMatch(val -> val < 0);
	}
}