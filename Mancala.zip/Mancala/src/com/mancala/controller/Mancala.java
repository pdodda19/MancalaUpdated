package com.mancala.controller;

import java.util.logging.Logger;

import com.mancala.exception.MancalaException;
import com.mancala.exception.StrategyException;
import com.mancala.model.Game;
import com.mancala.service.Steps;
import com.mancala.service.Strategy;

public class Mancala {

	private static final int[] boardOne = { 3, 3, 3 };
	private static final int[] boardTwo = { 3, 3, 3 };
	private static final int mancalaOne = 0;
	private static final int mancalaTwo = 0;
	private static final int player = 1;
	private static String gameStatus = "";
	private static final Logger log = Logger.getLogger(Mancala.class.getName());
	
	public static String startGame(int[] boardOne, int[] boardTwo, int mancalaOne, int mancalaTwo)
			throws MancalaException {
		{
			try {
				log.info("Starting game with Player :"+player);
				Game g = new Game(player, boardTwo, boardOne, mancalaOne, mancalaTwo);
				Steps util = new Steps();
				if (!util.gameOver(g)) {
					Strategy gr = new Strategy();
					gr.getGamePlay(g);
					gameStatus = "Game completed";
					return gameStatus;
				} else {
					gameStatus = "Game Over";
					return gameStatus;
				}
			} catch (StrategyException ex) {
				throw new MancalaException(ex.getMessage());
			}
		}

	}

	public static void main(String[] args) throws MancalaException {
		String result =startGame(boardOne, boardTwo, mancalaOne, mancalaTwo);
		log.info("Status :"+result);
	}
}
