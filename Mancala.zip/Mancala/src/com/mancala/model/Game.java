package com.mancala.model;

public class Game {
    private int player;
    private int[] boardOne;
    private int[] boardTwo;
    private int mancalaOne;
    private int mancalaTwo;
    private int boardSize;
    private boolean getAnotherTurn;
    
    public Game(int player, int[] boardOne, int[] boardTwo, int mancalaOne, int mancalaTwo){
        this.player=player;
        this.boardSize= boardTwo.length;
        this.boardTwo =new int[boardSize];
        this.boardOne =new int[boardSize];
        for(int i=0;i<boardSize;i++){
            this.boardTwo[i]= boardTwo[i];
            this.boardOne[i]= boardOne[i];
        }
        this.mancalaTwo = mancalaTwo;
        this.mancalaOne = mancalaOne;
    }

    public Game(Game game){
        player=game.getPlayer();
        boardSize=game.getBoardSize();
        this.boardTwo =new int[boardSize];
        this.boardOne =new int[boardSize];
        System.arraycopy(game.getBoardPlayerTwo(), 0, this.boardTwo, 0, boardSize);
        System.arraycopy(game.getBoardPlayerOne(), 0, this.boardOne, 0, boardSize);
        mancalaTwo =game.getMancalaPlayerTwo();
        mancalaOne =game.getMancalaPlayerOne();
        getAnotherTurn=game.getAnotherTurn();
    }  

    public int getBoardSize()
    {
        return boardSize;
    }
    
    public void setBoardSize(int boardSize){
        this.boardSize=boardSize;
    }
    
    public int getPlayer(){
        return player;
    }
    
    public void setPlayer(int player){
        this.player=player;
    }
    
    public int[] getBoardPlayerOne(){
        return boardOne;
    }
    
    public void setBoardPlayerOne(int[] board1){
        System.arraycopy(board1, 0, this.boardOne, 0, boardSize);
    }
    
    public int[] getBoardPlayerTwo(){
        return boardTwo;
    }
    
    public void setBoardPlayerTwo(int[] board2){
        System.arraycopy(board2, 0, this.boardTwo, 0, boardSize);
    }
    
    public int getMancalaPlayerOne(){
        return mancalaOne;
    }
    
    public void setMancalaPlayerOne(int mancalaOne){
        this.mancalaOne =mancalaOne;
    }    
    
    public int getMancalaPlayerTwo(){
        return mancalaTwo;
    }
    
    public void setMancalaPlayerTwo(int mancalaTwo){
        this.mancalaTwo =mancalaTwo;
    }
    
    public boolean getAnotherTurn(){
        return getAnotherTurn;
    }
    
    public void setAnotherTurn(boolean getAnotherTurn){
        this.getAnotherTurn=getAnotherTurn;
    }
}
