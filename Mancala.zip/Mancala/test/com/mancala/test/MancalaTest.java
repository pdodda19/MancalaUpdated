package com.mancala.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.mancala.controller.*;
import com.mancala.exception.MancalaException;

public class MancalaTest {

	private static final int[] boardOne = { 3, 3, 3 };
	private static final int[] boardTwo = { 3, 3, 3 };
	private static final int mancalaOne = 0;
	private static final int mancalaTwo = 0;

	/** * Initialization */

	/**
	 * * Test case for add method
	 * 
	 * @throws MancalaException
	 */
	@Test
	public void test() throws MancalaException {
		String gameStatus = Mancala.startGame(boardOne, boardTwo, mancalaOne, mancalaTwo);
		assertEquals("Game completed", gameStatus);
	}

	/** * destroy the object */

}
